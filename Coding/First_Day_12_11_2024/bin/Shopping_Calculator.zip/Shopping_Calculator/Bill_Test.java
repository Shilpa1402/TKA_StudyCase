package Shopping_Calculator;

public class Bill_Test {
	public static void main(String[] args) {
		 Grocery_Calculator g = new Grocery_Calculator();
		 g.discountedBill(100, 200, 50, 75, 300);
	}

}
